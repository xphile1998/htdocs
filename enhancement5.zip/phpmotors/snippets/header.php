<img src="/phpmotors/images/site/logo.png" alt="PHP Motors Logo">
<a class="head_para" href="accounts/?action=deliverLoginView" title="Login or Register with PHP Motors">My Account</a>
