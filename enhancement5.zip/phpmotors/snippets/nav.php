<?php 
if (!empty($navList)) {
    echo $navList; 
}
?>
