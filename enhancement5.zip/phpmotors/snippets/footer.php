<p class="foot_para">&copy; PHP Motors, All rights reserved.</p>
<p class="foot_para">All images used are believed to be in "Fair Use". Please notify the author if any are not and they will be removed.</p>
<p class="foot_para">Last Updated: <?php echo date('j F, Y', getlastmod()); ?></p>
