<header>
    <img src="/phpmotors/images/site/logo.png" alt="PHP Motors Logo">
    <p class="head_para">My Account</p>
</header>