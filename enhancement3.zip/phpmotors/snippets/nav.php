<nav class="navigation">
    <?php echo $navList; ?>
    <!-- <ul>
        <li class="menu_choice"><a href="#">Home</a></li>
        <li class="menu_choice"><a href="#">Classic</a></li>
        <li class="menu_choice"><a href="#">Sports</a></li>
        <li class="menu_choice"><a href="#">SUV</a></li>
        <li class="menu_choice"><a href="#">Trucks</a></li>
        <li class="menu_choice"><a href="#">Used</a></li>
    </ul> -->
</nav> 