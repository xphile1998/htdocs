<header>
    <img src="/phpmotors/images/site/logo.png" alt="PHP Motors Logo">
    <a class="head_para" href="accounts/index.php">My Account</a>
</header>