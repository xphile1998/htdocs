<?php 
if (!empty($navList)) {
    echo $navList; 
} 
// else {
//     echo "This appears to be broken..."
// }
?>
